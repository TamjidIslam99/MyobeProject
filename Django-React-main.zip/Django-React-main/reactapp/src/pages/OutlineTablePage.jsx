import React from 'react'
import OutlineTable from "../components/OutlineTable";

export const OutlineTablePage = () => {
  return (
      <div className='container-fluid g-0'>
        <OutlineTable/>
      </div>
  )
}


