import React from 'react'
import { CourseObjectiveWrapper } from '../components/CourseObjectiveWrapper'

export const CourseObjectivePage = () => {
  return (
    <div className='container-fluid g-0 Page'>
      <CourseObjectiveWrapper/>
    </div>
  )
}
