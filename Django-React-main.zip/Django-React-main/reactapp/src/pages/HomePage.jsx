import React, {Fragment} from 'react'
import Home from "../components/Home";

export const HomePage = () => {
  return (
    <Fragment>
        <Home/>
    </Fragment>
  )
}
