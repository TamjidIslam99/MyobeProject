import React from 'react'
import { CloWrapper } from '../components/CloWrapper'

export const CloPage = () => {
  return (
    <div className='container-fluid g-0 Page'>
      <CloWrapper/>
    </div>
  )
}
