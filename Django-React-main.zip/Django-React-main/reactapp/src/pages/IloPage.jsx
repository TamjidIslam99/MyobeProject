import React from 'react'
import { IloWrapper } from '../components/IloWrapper'

export const IloPage = () => {
  return (
    <div className='container-fluid g-0 Page'>
        <IloWrapper/>
    </div>
  )
}
