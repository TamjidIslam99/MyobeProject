import React from 'react'
import { PeoMapMissionTable } from '../components/PeoMapMissionTable'

export const PeoMapMissionPage = () => {
  return (
    <div>
        <PeoMapMissionTable/>
    </div>
  )
}
