import React from 'react';
import {Sidebar} from "../components/Sidebar";
import CloPloReasoning from "../components/CloPloReasoning";

function CloPloRePage(props) {
    return (
        <div>
            <CloPloReasoning/>
        </div>
    );
}

export default CloPloRePage;
