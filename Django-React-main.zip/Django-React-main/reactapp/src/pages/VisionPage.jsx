import React from 'react'
import { VisionWrapper } from '../components/VisionWrapper'

export const VisionPage = () => {
  return (
    <div className='container-fluid g-0 Page'>
      <VisionWrapper/>
    </div>
  )
}
