import React from 'react'
import { PloMapPeoTable } from '../components/PloMapPeoTable'

export const PloMapPeoPage = () => {
  return (
    <div> 
        <div className='container-fluid g-0 Page'>
            <PloMapPeoTable/>
        </div>
    </div>
  )
}
