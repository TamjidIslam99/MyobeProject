import React from 'react'
import {Course} from '../components/Course'

export const CoursePage = () => {
  return (
    <div className='container-fluid g-0'>
      <Course/>
    </div>
  )
}


