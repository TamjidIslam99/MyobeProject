import React from 'react'
import Curriculum from '../components/Curriculum'

export const CurriculumPage = () => {
  return (
    <div className='container-fluid g-0'>
      <Curriculum/>
  </div>
  )
}
export default CurriculumPage

