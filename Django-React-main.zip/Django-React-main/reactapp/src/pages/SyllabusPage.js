import React from 'react';
import Syllabus from "../components/Syllabus";

function SyllabusPage(props) {
    return (
        <div className='container-fluid g-0'>
            <Syllabus/>
        </div>
    );
}

export default SyllabusPage;