import React from 'react'
import { PeoWrapper } from '../components/PeoWrapper'

export const PeoPage = () => {
  return (
    <div className='container-fluid g-0 Page'>
      <PeoWrapper/>
    </div>
  )
}
