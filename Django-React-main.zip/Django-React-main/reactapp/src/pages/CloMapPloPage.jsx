import React from 'react'
import { Sidebar } from '../components/Sidebar'
import { CloMapPloTable } from '../components/CloMapPloTable'

export const CloMapPloPage = () => {
  return (
      <div className='container-fluid g-0 Page'>
          <CloMapPloTable/>
      </div>
  )
}
