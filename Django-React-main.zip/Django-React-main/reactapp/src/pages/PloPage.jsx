import React from 'react'
import { PloWrapper } from '../components/PloWrapper'

export const PloPage = () => {
  return (
    <div className='container-fluid g-0 Page'>
      <PloWrapper/>
    </div>

  )
}
