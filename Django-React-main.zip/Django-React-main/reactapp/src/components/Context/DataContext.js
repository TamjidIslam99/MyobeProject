import {createContext} from "react";

const DataContext = createContext(null);

export default DataContext;