import {createContext} from "react";

const CloContext = createContext(null);
export default CloContext;