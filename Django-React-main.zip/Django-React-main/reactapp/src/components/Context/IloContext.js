import {createContext} from "react";

const IloContext = createContext(null);

export default IloContext;