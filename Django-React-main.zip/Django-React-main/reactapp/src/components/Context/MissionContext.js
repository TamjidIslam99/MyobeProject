import {createContext} from "react";

const MissionContext = createContext(null);

export default MissionContext;