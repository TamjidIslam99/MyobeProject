import {createContext} from "react";

const PloPeoContext = createContext(null);

export default PloPeoContext;