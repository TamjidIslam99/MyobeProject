import {createContext} from "react";

const PeoContext = createContext(null);

export default PeoContext;